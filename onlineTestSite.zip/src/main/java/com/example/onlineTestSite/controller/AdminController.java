package com.example.onlineTestSite.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.onlineTestSite.entity.response.ExamScoreResultResponse;
import com.example.onlineTestSite.service.QuestionService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	QuestionService questionService;
	
	@GetMapping("/adminMain")
	public String adminMain(Model model) {
		List<ExamScoreResultResponse> examScoreList = questionService.getExamScoreResultList();
		model.addAttribute("examScoreList", examScoreList);
		return "/admin/adminMain";
	}
}
