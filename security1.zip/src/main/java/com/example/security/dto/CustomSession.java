package com.example.security.dto;

import java.util.HashMap;
import java.util.Map;


public class CustomSession {
	private final static Map<String, AuthObject> sessions = new HashMap<String, AuthObject>();
	
	//추가
	public static void addAttribute(String key, AuthObject value) {
		sessions.put(key, value);
	}
	
	//삭제
	public static void removeAttribute(String key) {
		sessions.remove(key);
	}
	
	//가져오기
	public static Object getAttribute(String key) {
		return sessions.get(key);
	}
}
