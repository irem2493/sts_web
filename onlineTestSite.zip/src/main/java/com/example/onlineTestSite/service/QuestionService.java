package com.example.onlineTestSite.service;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.example.onlineTestSite.dao.IQuestionDao;
import com.example.onlineTestSite.entity.request.ExampleRequest;
import com.example.onlineTestSite.entity.response.ExamScoreResultResponse;
import com.example.onlineTestSite.entity.response.QuestionResponse;

@Service
public class QuestionService {
	
	@Autowired
	IQuestionDao questionDao;
	
	public List<QuestionResponse> getQuestion5(String subjectId) {
		List<QuestionResponse> questionList = questionDao.getQuestion5(subjectId);
		
		for(int i=0; i<questionList.size(); i++) {
			questionList.get(i).setSelectAnswerList(questionDao.getSelectList(questionList.get(i).getQuestionId())); 
		}
		 
		return questionList;
	}
	public void calcScore(Map<String, String> answers) {
        
		Iterator<Map.Entry<String, String>> iterator = answers.entrySet().iterator();

		if (iterator.hasNext()) {
		    iterator.next(); // 첫 번째 요소를 건너뜁니다.
		}
		
		// 두 번째 요소 추출 (username 저장)
	    String username = null;
	    if (iterator.hasNext()) {
	        Map.Entry<String, String> entry = iterator.next();
	        username = entry.getValue(); // 두 번째 요소의 값을 username으로 저장
	        //System.out.println("사용자 이름: " + username);
	    }
		
	 // 세 번째 요소 추출 (subjectId 저장)
	    String subjectId = null;
	    if (iterator.hasNext()) {
	        Map.Entry<String, String> entry = iterator.next();
	        subjectId = entry.getValue(); // 두 번째 요소의 값을 username으로 저장
	        //System.out.println("과목 아이디: " + subjectId);
	    }
	    
		while (iterator.hasNext()) {
		    Map.Entry<String, String> answerMap = iterator.next();
		    //System.out.println("문제: " + answerMap.getKey() + " / 사용자의 답변: " + answerMap.getValue());
		    ExampleRequest example = new ExampleRequest(subjectId, username, answerMap.getKey(), answerMap.getValue());
		    //System.out.println(example);
		    questionDao.insertExamScore(example);
		}
		
		questionDao.updateExamScoreAC(subjectId, username);
        questionDao.updateExamScoreSA(subjectId, username);
        questionDao.insertExamScoreResult(subjectId, username);
	    
	}
	
	public List<ExamScoreResultResponse> getMyExamScoreResult(String username){
		List<ExamScoreResultResponse> eList = questionDao.selectMyExamScore(username);
		for(ExamScoreResultResponse e: eList) System.out.println(e + "---------------"+username);
		return eList; 
	}
}
