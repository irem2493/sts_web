package com.example.security3.entity;

import lombok.Data;

@Data
public class Board {
	private int bno;
	private String title;
	private String contents;
	private String username;
	private String regdate;
	private String modifydate;
}
