package com.example.security.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.security.dto.UserDto;

@Mapper
public interface ILoginDao {
	public UserDto login(@Param("username")String username, 
						@Param("pw")String pw);
	public void join(UserDto userDto);
	public UserDto findUsername(@Param("username")String username);
}
