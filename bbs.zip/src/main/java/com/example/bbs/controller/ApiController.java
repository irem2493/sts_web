package com.example.bbs.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.logging.Logger;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApiController {
    
    private static final Logger logger = Logger.getLogger(ApiController.class.getName());
    
    @RequestMapping("/api")
    public ResponseEntity<String> getTravelList() {
        StringBuilder urlBuilder = new StringBuilder("http://api.kcisa.kr/openapi/API_CNV_061/request"); /* URL */
        
        try {
            // URL 파라미터 추가
            urlBuilder.append("?" + URLEncoder.encode("serviceKey", "UTF-8") + "=517d452c-17c0-4246-ad52-ba44e57e4766"); /* 서비스키 */
            urlBuilder.append("&" + URLEncoder.encode("numOfRows", "UTF-8") + "=" + URLEncoder.encode("10", "UTF-8")); /* 세션당 요청레코드수 */
            urlBuilder.append("&" + URLEncoder.encode("pageNo", "UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /* 페이지수 */
            urlBuilder.append("&" + URLEncoder.encode("resultType", "UTF-8") + "=" + URLEncoder.encode("json", "UTF-8")); /* JSON 방식으로 호출 시 파라미터 resultType=json 입력 */
            
            URL url = new URL(urlBuilder.toString());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            
            // 타임아웃 설정 (연결 타임아웃 및 읽기 타임아웃)
            conn.setConnectTimeout(5000); // 5초 연결 타임아웃
            conn.setReadTimeout(5000);    // 5초 읽기 타임아웃
            
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-type", "application/json");
            
            // 응답 코드 확인
            int responseCode = conn.getResponseCode();
            logger.info("Response code: " + responseCode);
            
            BufferedReader rd;
            if (responseCode >= 200 && responseCode <= 300) {
                rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            } else {
                rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            }
            
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }
            rd.close();
            conn.disconnect();
            System.out.println(ResponseEntity.ok(sb.toString()));
            // 성공적인 응답 반환
            return ResponseEntity.ok(sb.toString());
            
        } catch (IOException e) {
            // 오류 처리
            logger.severe("Error during API call: " + e.getMessage());
            return ResponseEntity.status(500).body("API 호출 중 오류가 발생했습니다.");
        }
    }
}
