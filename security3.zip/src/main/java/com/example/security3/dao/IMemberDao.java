package com.example.security3.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.security3.entity.Member;

@Mapper
public interface IMemberDao {
	
	public void insert(@Param("member")Member member);
	
	public Member findByUsername(String username);
}
