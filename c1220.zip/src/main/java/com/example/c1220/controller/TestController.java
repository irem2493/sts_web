package com.example.c1220.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class TestController {

	@GetMapping("/test")
	public String testEndPoint() {
		System.out.println("testEndPoing....");
		return "Slow Mode Test입니다....";
	}
}
