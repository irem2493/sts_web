package com.example.onepagebbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnepagebbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnepagebbsApplication.class, args);
	}

}
