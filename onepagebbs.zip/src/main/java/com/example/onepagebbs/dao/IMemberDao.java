package com.example.onepagebbs.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.onepagebbs.dto.MemberDTO;

@Mapper
public interface IMemberDao {
	public List<MemberDTO> getList();
	public MemberDTO getMember(String id);
	public void insert(MemberDTO memberDto);
	public void update(MemberDTO memberDto);
	public void delete(String id);
	public List<MemberDTO> searchWrdID(@Param("searchWrd") String id);
	public List<MemberDTO> searchWrdName(@Param("searchWrd") String name);
}
