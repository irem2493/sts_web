package com.example.bbs.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.bbs.dto.BoardDTO;

@Mapper
public interface IBoardDao {
	public List<BoardDTO> getBList(@Param("startRow") int startRow, @Param("pageSize") int pageSize);
	public int BListCnt();
	public BoardDTO getBoard(int bno);
	public void updateRCnt(int bno);
	
	public void login(@Param("id") String id, @Param("id") String pw);
}
