package com.example.security3.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.security3.dao.IBoardDao;
import com.example.security3.entity.Board;

@Service
public class BoardService {
	
	@Autowired
	IBoardDao boardDao;
	
	public void registBoard(Board board) {
		boardDao.insertBoard(board);
	}
	
	public List<Board> getBoardList(){
		return boardDao.getBoardList();
	}
	
	public int getUserBoardCount(String username) {
		return boardDao.getUserBoardCnt(username);
	}
}
