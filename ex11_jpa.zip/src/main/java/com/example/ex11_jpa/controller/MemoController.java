package com.example.ex11_jpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.ex11_jpa.entity.Memo;
import com.example.ex11_jpa.repository.MemoRepository;
import com.example.ex11_jpa.vo.MemoVo;

@Controller
@RequestMapping("/memo")
public class MemoController {
	@Autowired
	MemoRepository memoRepository;
	@RequestMapping("/regMemo")
	public String regMemo(@RequestParam("userId") String userId, Model model) {
		System.out.println("regMemo");
		model.addAttribute("userId", userId);
		return "/memo/regMemo";
	}
	
	@PostMapping("/registMemo")
	public String registMemo(MemoVo memoVo) {
		System.out.println("registMemo");
		Memo memo = Memo.builder()
					.writer(memoVo.getWriter())
					.memoText(memoVo.getMemoText())
					.build();
		memoRepository.save(memo);
		System.out.println(memo.getWriter());
		return "redirect:/memo/listMemo?userId="+memo.getWriter();
	}
	@RequestMapping("/listMemo")
	public String listMemo(@RequestParam(value="userId", defaultValue="Guest") String userId, Model model) {
		System.out.println("listMemo.." + userId);
		List<Memo> mList = memoRepository.findAll();
		for(Memo m : mList) System.out.println(m);
		model.addAttribute("mList", mList);
		model.addAttribute("userId", userId);
		return "/memo/listMemo";
	}
	
	@RequestMapping("/myMemo")
	public String myMemo(@RequestParam("userId") String userId, Model model) {
		List<Memo> myList = memoRepository.findByWriter(userId);
		model.addAttribute("myList", myList);
		model.addAttribute("userId", userId);
		return "/memo/myMemo";
	}
}
