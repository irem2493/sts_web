package com.example.onlineTestSite.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.onlineTestSite.entity.response.Question;

@Mapper
public interface IQuestionDao {
	
	public List<Question> getQuestion5();
	
	public List<String> getSelectList(String questionId);
}
