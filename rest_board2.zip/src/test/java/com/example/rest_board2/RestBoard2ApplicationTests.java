package com.example.rest_board2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestBoard2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
