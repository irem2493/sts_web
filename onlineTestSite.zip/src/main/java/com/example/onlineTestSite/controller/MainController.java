package com.example.onlineTestSite.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.onlineTestSite.entity.Student;
import com.example.onlineTestSite.service.StudentService;


@Controller
public class MainController {
	
	@Autowired
	StudentService userService;

	@GetMapping("/")
	public String Main() {
		return "main";
	}
	
	@GetMapping("/registForm")
	public String registForm() {
		return "registForm";
	}
	
	@PostMapping("/registProc")
	public String registProc(Student student) {
		
		userService.regist(student);
		
		return "/loginForm";
	}
	
	@RequestMapping("/loginForm")
	public String loginForm(@RequestParam(value = "error", required = false) String error, Model model) {
	    if (error != null) {
	        model.addAttribute("error", "아이디, 비밀번호를 확인해주세요.");
	    }
	    return "/loginForm";
	}

}
