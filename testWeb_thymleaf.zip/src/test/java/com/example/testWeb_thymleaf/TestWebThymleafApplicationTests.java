package com.example.testWeb_thymleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestWebThymleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
