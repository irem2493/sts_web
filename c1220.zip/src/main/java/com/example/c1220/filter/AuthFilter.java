package com.example.c1220.filter;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AuthFilter implements Filter{

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest)request;
		HttpServletResponse httpResponse = (HttpServletResponse)response;
		
		
		/*
		 * //헤더 인증 방식 String token = httpRequest.getHeader("Authorize");
		 * System.out.println("AuthFilter ... token >> " + token);
		 * 
		 * if(token == null || !token.equals("mytoken")) {
		 * httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		 * System.out.println("인증불가 - 토큰있어?");
		 * 
		 * return; }
		 * 
		 * chain.doFilter(httpRequest, response);
		 */
		
		Cookie[] cookies = httpRequest.getCookies();
		
		if(cookies != null) {
			for(Cookie cookie : cookies) {
				if("auth".equals(cookie.getName())) {
					String authToken = cookie.getValue();
					System.out.println("Auth token : " + authToken);
					
					if(isVlaidAuthToken(authToken)) {
						chain.doFilter(httpRequest, httpResponse);
						return;
					}
				}
			}	
		}
		httpResponse.setStatus(401);
	}
	
	private boolean isVlaidAuthToken(String token) {
		return "authenticated".equals(token);
	}

}
