package com.example.c1220.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/secure")
public class SecureController {
	
	@GetMapping("/secu1")
	public ResponseEntity<String> secu1(HttpServletRequest request){
		
		return ResponseEntity.status(HttpStatus.OK).body("secu1...");
	}
	
	@GetMapping("/secu2")
	public ResponseEntity<String> secu2(HttpServletRequest request){
		return ResponseEntity.status(HttpStatus.OK).body("secu2...");
	}
}
