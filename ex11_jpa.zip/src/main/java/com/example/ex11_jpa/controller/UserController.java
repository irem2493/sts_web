package com.example.ex11_jpa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.ex11_jpa.entity.User;
import com.example.ex11_jpa.repository.UserRepository;
import com.example.ex11_jpa.vo.UserVo;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserRepository userRepository;
	
	@RequestMapping("/join")
	public String join() {
		System.out.println("join...");
		return "/user/join";
	}
	
	@PostMapping("/regUser")
	public String regUser(UserVo userVo) {
		System.out.println("regUser..."+userVo);
		User user = User.builder()
					.id(userVo.getId())
					.pw(userVo.getPw())
					.name(userVo.getName())
					.build();
		userRepository.save(user);
		return "/main";
	}
	
	@RequestMapping("/login")
	public String login() {
		System.out.println("login...");
		return "/user/login";
	}
	
	@PostMapping("/loginUser")
	public String loginUser(UserVo userVo, HttpSession session, RedirectAttributes rttr) {
		System.out.println("loginUser..."+userVo);
		User user = userRepository.findByIdAndPw(userVo.getId(), userVo.getPw());
		if(user != null) {
			System.out.println(user.getId());
			session.setAttribute("userId", user.getId()); 
			rttr.addFlashAttribute("userId", user.getId());
			return "redirect:/";
		}else {
			rttr.addFlashAttribute("loginYn", "fail");
			return "redirect:/user/join";
		}
	}
	
	@RequestMapping("/logout")
	public String logout(@RequestParam("userId") String userId, HttpSession session) {
		System.out.println("logout...");
		session.invalidate();
		return "/main";
	}
}
