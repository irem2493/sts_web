package com.example.onlineTestSite.secu;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import com.example.onlineTestSite.conponent.CustomAuthenticationSuccessHandler;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
	
	@Autowired
    private CustomAuthenticationSuccessHandler customAuthenticationSuccessHandler;
	
	@Bean
	BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
		
		http
				.authorizeHttpRequests((auth)->auth
						
						//메인, 회원등록은 모든 사용자 허용
						.requestMatchers("/", "/registForm","/loginForm","/registProc", "/loginProc","/logout").permitAll()
						.requestMatchers("/css/**","/js/**").permitAll()
						.requestMatchers("/student/**").hasAnyRole("ADMIN","STUDENT")
						.requestMatchers("/admin/**").hasRole("ADMIN")
						.anyRequest().authenticated()
						);
		
		//로그인 부분
		http
					.formLogin((auth) -> auth
								
								//내가 만든 
								.loginPage("/loginForm")
								.loginProcessingUrl("/loginProc")
							
								//mypage로 가려다가 거부당함
								//admin으로 로그인했을 때 adminMain.html로 이동됨
								.successHandler(customAuthenticationSuccessHandler)
								
								//로그인 실패되었을 때
								.failureUrl("/loginForm?error")
								.permitAll()
								);
		
		
		http 
			.logout((auth)-> auth
				
				.logoutSuccessUrl("/") );
		
		 
		
		//post인 경우
		/*http
				.csrf(auth -> auth.disable());*/
		
		return http.build();
	}
}
