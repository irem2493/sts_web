package com.example.security.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.junit.jupiter.api.Test;

class password {

	@Test
	void join() {
		String pw = "1234";
		String epw = pw(pw);
		
		char ckey = epw.charAt(epw.length()-1);
		int ikey = Integer.parseInt(String.valueOf(ckey));
		
		System.out.println(ikey);
		
		char[] pwArr = pw.toCharArray();
		String newPw =new String();
		for(int i = 0; i < pwArr.length; i++) {
			newPw += pwArr[i];
			for(int j = 0; j < ikey; j++) {
				newPw += "x";
			}
		}
		newPw += ikey;
		
		System.out.println(newPw);
		if(newPw.equals(epw)) System.out.println("같다");
	}
	
	String pw(String pw) {
		char[] pwArr = pw.toCharArray();
		String newPw =new String();
		Map<String,String> pwMap = new HashMap<String, String>();
		Random random = new Random();
		int key = random.nextInt(5)+1;
		System.out.println(key);
		for(int i = 0; i < pwArr.length; i++) {
			newPw += pwArr[i];
			for(int j = 0; j < key; j++) {
				newPw += "x";
			}
		}
		newPw += key;
		System.out.println(newPw);
		return newPw;
	}
	
}
