package com.example.onepagebbs.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.onepagebbs.dao.IMemberDao;
import com.example.onepagebbs.dto.MemberDTO;

@Controller
public class MyController {
	@Autowired
	IMemberDao mDao;
	@RequestMapping("/")
	public String root(Model model) {
		System.out.println("main...");
		return "main";
	}
	
	@PostMapping("/insert")
	public @ResponseBody String insert(@RequestBody MemberDTO memberDTO) {
		
		System.out.println("insert..."+memberDTO);
		String msg="";
		if(memberDTO != null) {
			mDao.insert(memberDTO);
			msg = "회원등록 완료!";
		}else {
			msg = "회원등록 실패!";
		}
		return msg;
	}
	
	@GetMapping("/checkId")
	public @ResponseBody String checkId(@RequestParam("id") String id) {
		System.out.println(id.length());
		MemberDTO member=null;
		String result="not use";
		if(id != null && id.length() > 0) {
			member = mDao.getMember(id);
			if(member != null) result="use";
		}
		 return result;
	}
	
	@RequestMapping("/list")
	public String list(RedirectAttributes redirectAttributes) {
		System.out.println("list...");
		List<MemberDTO> mList = mDao.getList();
		for(MemberDTO m : mList) System.out.println(m);
		// 리다이렉트 후에 데이터를 전달하려면 RedirectAttributes 사용
	    redirectAttributes.addFlashAttribute("mList", mList);
		return "redirect:/";
	}
	/*@PostMapping("/getOneMember")
	public String getOneMember(@RequestParam("id") String id,RedirectAttributes redirectAttributes) {
		System.out.println("getOneMember..."+id);
		MemberDTO m = mDao.getMember(id);
		System.out.println(m);
		// 리다이렉트 후에 데이터를 전달하려면 RedirectAttributes 사용
	    redirectAttributes.addFlashAttribute("member", m);
		return "redirect:/";
	}*/
	
	@PostMapping("/search")
	public String search(@RequestParam("searchSel") String searchSel, @RequestParam("searchWrd") String searchWrd, RedirectAttributes redirectAttributes) {
		System.out.println("search...");
		System.out.println("searchSel : "+searchSel+", searchWrd : "+searchWrd);
		List<MemberDTO> mList = null;
		if(searchSel.equals("id")) {
			if(mDao.searchWrdID(searchWrd) != null)
				mList=mDao.searchWrdID(searchWrd);
		}else {
			if(mDao.searchWrdName(searchWrd) != null)
				mList=mDao.searchWrdName(searchWrd);
		}
		redirectAttributes.addFlashAttribute("mList", mList);
		return "redirect:/";
	}
	
	@GetMapping("/getOneMember/{id}")
	public @ResponseBody MemberDTO getOneMember(@PathVariable("id") String id, Model model) {
		
		System.out.println("getOneMember..."+id);
		 // 아이디로 회원 조회
	    MemberDTO member = mDao.getMember(id);
	    System.out.println(member);
	    return member;
	}
	
	@PostMapping("/modMember")
	public String modMember(RedirectAttributes redirectAttributes, MemberDTO memberDTO) {
		System.out.println("modMember..."+memberDTO);
		mDao.update(memberDTO);
		// 리다이렉트 후에 데이터를 전달하려면 RedirectAttributes 사용
	    redirectAttributes.addFlashAttribute("member", memberDTO);
		return "redirect:/list";
	}
	
	@PostMapping("/delMember")
	public String delMember(@RequestParam("id") String id) {
		System.out.println("delMember..."+id);
		mDao.delete(id);
		return "redirect:/list";
	}
}
