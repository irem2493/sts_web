package com.example.security3.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.security3.entity.Board;
import com.example.security3.service.BoardService;
import com.example.security3.service.RankService;

@Controller
@RequestMapping("/board")
public class BoardController {
	
	@Autowired
	BoardService boardService;
	
	@Autowired
	RankService rankService;
	
	@GetMapping("/boardRegistForm")
	public String boardRegistForm(Model model, Principal principal) {
		model.addAttribute("username", principal.getName());
		return  "/board/boardRegistForm";
	}
	
	@PostMapping("/registBoard")
	public String registBoard(Board board, Principal principal) {
		String username = principal.getName();
		
		rankService.updateRank(username);

		boardService.registBoard(board);
		return "redirect:/board/boardListPage";
	}
	

	@GetMapping("/boardListPage") 
	public String boardList(Model model) { 
		List<Board> boardList = boardService.getBoardList(); 
		for(Board b : boardList) System.out.println(b); 
		model.addAttribute("boardList", boardList); 
		return "/board/boardListPage"; 
	}

	
}
