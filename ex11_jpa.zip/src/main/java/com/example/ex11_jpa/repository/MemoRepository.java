package com.example.ex11_jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ex11_jpa.entity.Memo;

public interface MemoRepository extends JpaRepository<Memo, Long>{
	List<Memo> findByWriter(String writer);
}
