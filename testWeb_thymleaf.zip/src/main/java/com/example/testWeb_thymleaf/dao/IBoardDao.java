package com.example.testWeb_thymleaf.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.testWeb_thymleaf.dto.BoardDto;


@Mapper
public interface IBoardDao {
	//등록 
		public int insert(@Param("board") BoardDto board);
		
		//목록 조회
		public List<BoardDto> findAll();
		
		//목록조회(페이지네이션)
		public List<BoardDto> findAllPaging(@Param("startNum") int startNum, @Param("endNum") int endNum);
		
		//개별 조회
		public BoardDto findByBno(int bno);
		
		//게시글 수 
		public int findCount();
		
		//수정
		public int update(@Param("board") BoardDto board);
		
		//삭제
		public int delete(int bno);
}
