package com.example.onlineTestSite.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.onlineTestSite.dao.IStudentDao;
import com.example.onlineTestSite.entity.Student;


@Service
public class StudentService {
	@Autowired
	private IStudentDao studentDao;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	public void regist(Student student) {
		//폼으로부터 입력받은 패스워드 암호화
		String encodedPassword = bCryptPasswordEncoder.encode(student.getPassword());
		student.setPassword(encodedPassword);
		
		//역할 부여
		student.setRole("ROLE_STUDENT");
		
		studentDao.insertUser(student);
	}
	
}
