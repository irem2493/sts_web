package com.example.onepagebbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnepagebbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
