package com.example.security3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.security3.entity.Member;
import com.example.security3.service.MemberService;
import com.example.security3.service.RankService;

@Controller
public class MainController {
	
	@Autowired
	private MemberService memberService;
	
	@Autowired
	private RankService rankService;
	
	@GetMapping("/")
	public String main(Model model) {
		
		return "main";
	}
	
	@GetMapping("/registForm")
	public String registForm() {
		return "registForm";
	}
	
	@PostMapping("/registProc")
	public String registProc(Member member) {
		
		memberService.regist(member);
		rankService.registRank(member.getUsername());
		
		return "redirect:/login";
	}
	
	@GetMapping("/loginForm")
	public String loginForm() {
		return "/loginForm";
	}
	
	
	
	/*
	 * @PostMapping("/loginProc") public String loginProc(@RequestParam String
	 * username, @RequestParam String password, Model model) { Authentication
	 * authentication = SecurityContextHolder.getContext().getAuthentication();
	 * CustomUserDetails userDetails =
	 * (CustomUserDetails)authentication.getPrincipal();
	 * model.addAttribute("userDetails", userDetails);
	 * 
	 * return "main";
	 * 
	 * }
	 */
	 

}
