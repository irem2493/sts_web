package com.example.ex11_jpa.vo;

import lombok.Data;

@Data
public class MemoVo {
	private String writer;
	private String memoText;
}
