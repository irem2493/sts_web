package com.example.onlineTestSite.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.onlineTestSite.entity.response.Question;
import com.example.onlineTestSite.service.QuestionService;

@Controller
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	QuestionService questionService;
	
	@GetMapping("/studentMain")
	public String studentMain() {
		return "/student/studentMain";
	}
	
	@GetMapping("/studentTest")
	public String studentTest(Model model, Principal principal) {
		List<Question> questionList = questionService.getQuestion5();
		for(Question q : questionList)System.out.println(q);
		model.addAttribute("questionList", questionService.getQuestion5());
		model.addAttribute("username", principal.getName());
		return "/student/studentTest";
	}
}
