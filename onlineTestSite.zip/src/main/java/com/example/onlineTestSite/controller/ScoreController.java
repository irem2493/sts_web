package com.example.onlineTestSite.controller;

import java.util.Iterator;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/score")
public class ScoreController {

	@PostMapping("/calcScore")
	public String calcScore(@RequestParam Map<String, String> answers, Model model) {
        
		Iterator<Map.Entry<String, String>> iterator = answers.entrySet().iterator();

		if (iterator.hasNext()) {
		    iterator.next(); // 첫 번째 요소를 건너뜁니다.
		}
		
		// 두 번째 요소 추출 (username 저장)
	    String username = null;
	    if (iterator.hasNext()) {
	        Map.Entry<String, String> entry = iterator.next();
	        username = entry.getValue(); // 두 번째 요소의 값을 username으로 저장
	        System.out.println("사용자 이름: " + username);
	    }
		
	 // 세 번째 요소 추출 (subjectId 저장)
	    String subjectId = null;
	    if (iterator.hasNext()) {
	        Map.Entry<String, String> entry = iterator.next();
	        subjectId = entry.getValue(); // 두 번째 요소의 값을 username으로 저장
	        System.out.println("과목 아이디: " + subjectId);
	    }
	    
		while (iterator.hasNext()) {
		    Map.Entry<String, String> answerMap = iterator.next();
		    System.out.println("문제: " + answerMap.getKey() + " / 사용자의 답변: " + answerMap.getValue());
		    
		}
        
        return "";
	}
}
