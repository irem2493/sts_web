package com.example.bbs.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.bbs.dto.UserDTO;

@Mapper
public interface IUserDao {
	public UserDTO getUser(String id);
	public void insertUser(@Param("userDTO")  UserDTO userDTO);
}
