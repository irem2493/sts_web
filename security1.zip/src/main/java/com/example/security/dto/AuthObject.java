package com.example.security.dto;

import lombok.Data;

@Data
public class AuthObject {
	private boolean loginYN = false;
	private UserDto userDto;
	
	public void checkAuthObject(UserDto userDto, String pw){
		String epw = userDto.getPw();
		char ckey = epw.charAt(epw.length() - 1);
		int key = Integer.parseInt(String.valueOf(ckey));
		
		String newPw = EncryptPW.encryptPw(pw, key);
		
		if (epw.equals(newPw)) {
			loginYN = true;
			this.userDto = userDto;
		}
	}
}
