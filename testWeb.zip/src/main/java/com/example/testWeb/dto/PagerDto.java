package com.example.testWeb.dto;

import lombok.Data;

@Data
public class PagerDto {
	private int startNum;		//페이지 시작
	private int pageNum; 		//현재 페이지
	private int totalNum;		//게시판 전체 수
	private int amount;			//한 페이지에 보여줄 개수
	
	private int totalPage;		//전체 페이지
	private int totalCnt;		
	private int prevPage;
	private int nextPage;
	
	public PagerDto(int pageNum, int totalNum, int amount ) {
		this.pageNum = pageNum;
		this.totalNum = totalNum;
		this.amount = amount;
		
		calc();
	}
	
	private void calc() {
		startNum = pageNum * amount - amount;
		totalPage = Math.ceilDiv(totalNum, amount);
		
		prevPage = pageNum - 1;
		if(prevPage < 0) prevPage = 1;
		
		nextPage = pageNum + 1;
		if(totalPage < nextPage) nextPage = totalPage;
	}
}

