package com.example.rest_board2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.rest_board2.dao.IBoardDao;
import com.example.rest_board2.domain.Board;


@Controller
@RequestMapping("/board")
public class BoardController {
	
	@Autowired
	IBoardDao boardDao;
	
	@GetMapping("/boardForm")
	public String regBoard(@RequestParam(value="bno", required=false) Integer bno, Model model) {
		
		if (bno == null) {
	        model.addAttribute("buttonText", "게시글 등록하기");
	    } else {
	    	System.out.println(bno+"---------------bno");
	    	Board board = boardDao.getBoard(bno);
	        model.addAttribute("buttonText", "게시글 수정하기");
	        model.addAttribute("bno", bno);
	        model.addAttribute("board", board);
	    }
	    return "/board/boardForm";
	}
	
}
