package com.example.testWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
