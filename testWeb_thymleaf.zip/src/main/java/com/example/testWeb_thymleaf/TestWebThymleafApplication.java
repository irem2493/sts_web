package com.example.testWeb_thymleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestWebThymleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestWebThymleafApplication.class, args);
	}

}
