package com.example.ex11_jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.ex11_jpa.entity.User;

public interface UserRepository extends JpaRepository<User, String>{
	User findByIdAndPw(String id, String pw);
	
	/*@Query("SELECT COUNT(*) FROM User u WHERE u.id=?1 AND u.pw = ?2")
	int loginCheck(String id, String pw);
	
	
	@Query("SELECT u.id, u.name, m.memoText FROM User u INNTER JOIN Memo m ON u.id = m.writer")
	List<Object[]> getUserJoinMemo();//u.id를 객체로, u.name을 객체로, m.memoText를 객체로 해서 Object[] 하겠다.*/
}
