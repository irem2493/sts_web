package com.example.ex11_jpa.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.ex11_jpa.entity.Memo;
import com.example.ex11_jpa.repository.MemoRepository;
import com.example.ex11_jpa.vo.MemoVo;

@Controller
@RequestMapping("/memo")
public class MemoController {
	@Autowired
	MemoRepository memoRepository;
	@RequestMapping("/regMemo")
	public String regMemo(@RequestParam("userId") String userId, Model model) {
		System.out.println("regMemo");
		model.addAttribute("userId", userId);
		return "/memo/regMemo";
	}
	
	@PostMapping("/registMemo")
	public String registMemo(MemoVo memoVo) {
		System.out.println("registMemo");
		Memo memo = Memo.builder()
					.mno(memoVo.getMno())
					.writer(memoVo.getWriter())
					.memoText(memoVo.getMemoText())
					.build();
		memoRepository.save(memo);
		System.out.println(memo.getWriter());
		return "redirect:/memo/listMemo?userId="+memo.getWriter();
	}
	@RequestMapping("/listMemo")
	public String listMemo(@RequestParam(value="userId",defaultValue="Guest") String userId
			,@RequestParam(value="pageNum", defaultValue="1") int pageNum 
			,@RequestParam(value="amount", defaultValue = "5") int amount
			,Model model) {
		System.out.println("listMemo.." +userId + pageNum+ amount);
		
		Sort sort1 = Sort.by("mno").descending();
		Pageable pageable;
		if(pageNum > 0) pageable = PageRequest.of(pageNum-1, amount, sort1);
		else pageable = PageRequest.of(pageNum, amount, sort1);
		
		Page<Memo> result = memoRepository.findAll(pageable);
		/*result.get().forEach(memo -> {
			System.out.println(memo);
		});;
		
		System.out.println("Total page : "+result.getTotalPages());	//총 페이지 수
		System.out.println("Total count : " + result.getTotalElements());	//전체 개수
		System.out.println("Page Number : " + result.getNumber());	//현재 페이지 번호(0부터 시작)
		System.out.println("Page Size : " + result.getSize()); 	//페이지당 데이터 개수
		System.out.println("has next page ?" + result.hasNext());	//다음 페이지 존재 여부
		System.out.println("first page?" + result.isFirst());	// 시작 페이지(0) 여부*/
		
		model.addAttribute("userId", userId);
		model.addAttribute("mList", result);
		model.addAttribute("totalCnt", result.getTotalElements());
		model.addAttribute("totalPage", result.getTotalPages());
		model.addAttribute("hasNextPage", result.hasNext());
		model.addAttribute("pageNum", result.getNumber());
		model.addAttribute("amount", amount);
		return "/memo/listMemo";
	}
	
	@RequestMapping("/myMemo")
	public String myMemo(@RequestParam("userId") String userId
			, @RequestParam(value="pageNum", defaultValue="1") int pageNum 
			,@RequestParam(value="amount", defaultValue = "5") int amount
			,Model model) {
		System.out.println("myMemo.." +userId + pageNum);
		
		Sort sort1 = Sort.by("mno").descending();
		Pageable pageable;
		if(pageNum > 0) pageable = PageRequest.of(pageNum-1, amount, sort1);
		else pageable = PageRequest.of(pageNum, amount, sort1);
		
		Page<Memo> result = memoRepository.findByWriter(userId, pageable);
		
		model.addAttribute("userId", userId);
		model.addAttribute("myList", result);
		model.addAttribute("totalCnt", result.getTotalElements());
		model.addAttribute("totalPage", result.getTotalPages());
		model.addAttribute("hasNextPage", result.hasNext());
		model.addAttribute("pageNum", result.getNumber());
		model.addAttribute("amount", amount);
		return "/memo/myMemo";
	}
	
	@RequestMapping("/updMemo")
	public String updMemo(@RequestParam("mno") Long mno, Model model) {
		System.out.println("updMemo..." + mno);
		Optional<Memo> result = memoRepository.findById(mno);
		
		if(result.isPresent()) {
			Memo memo = result.get();
			System.out.println(memo);
			model.addAttribute("memo", memo);
		}
		return "/memo/updMemo";	
	}
	
	@PostMapping("/updateMemo")
	public String updateMemo(MemoVo memoVo) {
		System.out.println("updateMemo...");
		Memo memo = Memo.builder()
				.mno(memoVo.getMno())
				.writer(memoVo.getWriter())
				.memoText(memoVo.getMemoText())
				.build();
		memoRepository.updateMemo(memo);
		System.out.println(memo.getWriter());
		return "redirect:/memo/myMemo?userId="+memoVo.getWriter();
	}
	
	@RequestMapping("/delMemo")
	public String delMemo(@RequestParam("mno") Long mno, @RequestParam("userId") String userId) {
		System.out.println("deleteMemo..."+ mno+userId);
		memoRepository.deleteMemo(mno);
		return "redirect:/memo/myMemo?userId="+userId;
	}
}
