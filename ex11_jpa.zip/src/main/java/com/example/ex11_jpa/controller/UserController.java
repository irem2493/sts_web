package com.example.ex11_jpa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.ex11_jpa.entity.User;
import com.example.ex11_jpa.repository.UserRepository;
import com.example.ex11_jpa.vo.UserVo;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserRepository uRep;
	
	@RequestMapping("/join")
	public String join() {
		System.out.println("join...");
		return "/user/join";
	}
	
	@PostMapping("/regUser")
	public String regUser(UserVo userVo) {
		System.out.println("regUser..."+userVo);
		User user = User.builder()
					.id(userVo.getId())
					.pw(userVo.getPw())
					.name(userVo.getName())
					.build();
		uRep.save(user);
		return "/main";
	}
	
	@RequestMapping("/login")
	public String login() {
		System.out.println("login...");
		return "/user/login";
	}
	
	@PostMapping("/loginUser")
	public String loginUser(UserVo userVo, HttpSession session, RedirectAttributes rttr) {
		System.out.println("loginUser..."+userVo);
		User user = uRep.findByIdAndPw(userVo.getId(), userVo.getPw());
		System.out.println(user.getId()+", "+user.getPw());
		if(user.getId() != null && user.getPw() != null) {
			System.out.println(user.getId());
			session.setAttribute("userId", user.getId()); 
			rttr.addFlashAttribute("userId", user.getId());
			return "redirect:/";
		}else return "/user/login";
	}
}
