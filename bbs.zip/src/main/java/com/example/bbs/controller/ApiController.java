package com.example.bbs.controller;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ApiController {
	private final String BASE_URL  = "http://api.kcisa.kr/openapi/API_CNV_061/request";
	private final String SERVICE_KEY = "517d452c-17c0-4246-ad52-ba44e57e4766";
	@RequestMapping("/api")
	public ResponseEntity<String> getTravelList(){
		//url생성
		String url = String.format("%s?serviceKey=%s&pageNo=5&numOfRows=10&resultType=json", 
                BASE_URL, SERVICE_KEY);
		
		 // RestTemplate을 사용하여 API 호출
        RestTemplate restTemplate = new RestTemplate();
        // HTTP GET 요청을 보내고 응답 받기
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
        
        // 응답 데이터 반환
        return ResponseEntity.ok(response.getBody());
	}
}
