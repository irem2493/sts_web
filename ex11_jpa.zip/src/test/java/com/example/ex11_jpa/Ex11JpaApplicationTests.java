package com.example.ex11_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex11JpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
