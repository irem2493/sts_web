package com.example.security3.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.security3.dao.IMemberDao;
import com.example.security3.entity.Member;

@Service
public class MemberService {
	
	@Autowired
	private IMemberDao memberDao;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	public void regist(Member member) {
		//폼으로부터 입력받은 패스워드 암호화
		String encodedPassword = bCryptPasswordEncoder.encode(member.getPassword());
		member.setPassword(encodedPassword);
		
		//역할 부여
		member.setRole("ROLE_MEMBER");
		
		memberDao.insert(member);
	}
}
