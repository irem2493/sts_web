package com.example.onlineTestSite.secu;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.example.onlineTestSite.entity.Student;

public class CustomUserDetails implements UserDetails{
	
	static final long serialVersionUID = 1L;
	
	private Student student;
	
	public CustomUserDetails(Student student) {
		this.student = student;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		Collection<GrantedAuthority> collection = new ArrayList<>();
		collection.add(new GrantedAuthority() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public String getAuthority() {
				return student.getRole();
			}
			
		});
		
		//return 부분은 null이면 안된다.
		return collection;
	}

	@Override
	public String getPassword() {
		return student.getPassword();
	}

	@Override
	public String getUsername() {
		return student.getUsername();
	}
	
	public String getName() {
		return student.getName();
	}
	
	public String getRole() {
		return student.getRole();
	}
	
}
