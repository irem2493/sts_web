package com.example.bbs.dto;

import java.time.LocalDate;

import lombok.Data;

@Data
public class UserDTO {
	private int uno;
	private String id;
	private String pw;
	private String name;
	private String postcode;
	private String roadAddress;
	private String jibunAddress;
	private String detailAddress;
	private String extraAddress;
	private LocalDate joinDate;
	private LocalDate modifyDate;
	private LocalDate loginDate;
	private LocalDate logoutDate;
	private String filename;
	private int fileSize;
}
