/**
 * 
 */


function validateRadioButton() {
    // 라디오 버튼 그룹의 이름이 'radioGroup'이라고 가정
    var radios = document.getElementsByName("radioGroup");

    // 라디오 버튼 중 선택된 것이 있는지 확인
    var isChecked = false;
    for (var i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            isChecked = true;
            break;
        }
    }

    // 선택되지 않았으면 alert 띄우기
    if (!isChecked) {
        alert("라디오 버튼을 선택해 주세요!");
        return false;  // 폼 제출을 막음
    }

    return true;  // 선택되었으면 폼 제출 가능
}
