package com.example.security3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Security3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
