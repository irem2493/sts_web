package com.example.rest_board2.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.rest_board2.domain.Board;

@Mapper
public interface IBoardDao {
	public Board getBoard(int bno);
	public void regBoard(@Param("board")Board Board);
	public void updateBoard(@Param("board")Board Board);
	public void delBoard(int bno);
	public List<Board> getBoardList();
}
