package com.example.onlineTestSite.entity.response;


import java.util.List;

import lombok.Data;

@Data
public class QuestionResponse {
	private String questionId;  // 문제 ID
    private String subjectId;   // 과목 ID 
    private String content;     // 문제 내용
    private String problemType; // 문제 유형 (TYPE_CHOICE 또는 TYPE_SA)
    private int score;   
    private List<String> selectAnswerList;
}
