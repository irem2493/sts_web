package com.example.ex11_jpa.repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.ex11_jpa.entity.Memo;
import com.example.ex11_jpa.entity.User;

@SpringBootTest
class MemoRepositoryTest {

	@Autowired
	MemoRepository memoRepository;
	
	@Autowired
	UserRepository userRepository;
	@Test
	void testQueryMethod2() {
		User user = userRepository.findByIdAndPw("test1", "test1");
		System.out.println(user);
	}
	
	//@Test
	void testQueryMethod1() {
		/*List<Memo> list = memoRepository.findByMnoBetweenOrderByMnoDesc(70L, 80L);
		for(Memo m : list)System.out.println(m);*/
	}
	
	//@Test
	void testDelete() {
		Long mno = 100L;
		memoRepository.deleteById(mno);
	}
	
	//@Test
	void testUpdate() {
		Memo memo = Memo.builder().mno(100L).memoText("Update Text").build();
		System.out.println(memoRepository.save(memo));
	}
	
	
	//@Test
	void testSelectAll() {
		List<Memo> mList = memoRepository.findAll();
		for(Memo m : mList) System.out.println(m);
	}
	
	//@Test
	void testSelect() {
		Long mno = 100L;
		Optional<Memo> result = memoRepository.findById(mno);
		
		if(result.isPresent()) {
			Memo memo = result.get();
			System.out.println(memo);
		}
	}
	
	//@Test
	void testInsertDummies() {
		/*
		for(int i = 1; i <= 100; i++) {
			Memo memo = Memo.builder()
					.memoText("Sample..." + i)
					.build();
			memoRepository.save(memo);
		}*/
		
		IntStream.rangeClosed(101, 200).forEach(i -> {
			Memo memo = Memo.builder().memoText("Sample..." + i).build();
			memoRepository.save(memo);
		});
	}
}
