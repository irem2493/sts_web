package com.example.bbs.dto;

import java.time.LocalDate;

import lombok.Data;
@Data
public class BoardDTO {
	private int bno;
	private String title;
	private String contents;
	private LocalDate bCreateDate;
	private LocalDate bUpdateDate;
	private String uid;
	private int readCount;
	private int commentCount;
}
