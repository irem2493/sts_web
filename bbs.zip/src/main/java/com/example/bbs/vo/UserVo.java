package com.example.bbs.vo;

import java.time.LocalDate;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class UserVo {
	private int uno;
	private String id;
	private String pw;
	private String name;
	private String postcode;
	private String roadAddress;
	private String jibunAddress;
	private String detailAddress;
	private String extraAddress;
	private MultipartFile file;
	private int fileSize;
}
