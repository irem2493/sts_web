package com.example.onlineTestSite.entity.response;

import lombok.Data;

@Data
public class ExamScoreResultResponse {
	private int examNo;           // 시험 번호
    private String subjectId;     // 과목 ID
    private String username;      // 응시자명
    private int sum;              // 점수 합계
    private String examDate;   	  // 시험 날짜
}
