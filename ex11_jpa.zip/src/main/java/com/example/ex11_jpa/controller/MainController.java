package com.example.ex11_jpa.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class MainController {
	@RequestMapping("/")
	public String root(HttpSession session) {
		String userId = (String)session.getAttribute("userId");
		System.out.println("main..." + userId);
		return "main";
	}
}
