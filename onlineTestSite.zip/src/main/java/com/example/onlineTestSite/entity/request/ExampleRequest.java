package com.example.onlineTestSite.entity.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExampleRequest {
	private String subjectId;      // 과목 ID
    private String username;       // 사용자 이름
    private String questionId;     // 문제 ID
    private String selectAnswer;   // 사용자가 선택한 답변
}
