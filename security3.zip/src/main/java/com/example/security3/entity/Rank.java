package com.example.security3.entity;

import lombok.Data;

@Data
public class Rank {
	private String username;
	private int bcount;
	private String grade;
}
