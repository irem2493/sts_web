package com.example.c1220.filter;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;

//@WebFilter("/*") --이렇게 사용하면 세밀하게 설정하기 어렵다.
public class SlowModeFilter implements Filter{

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest)request;
		
		//요청 시작 기간 기록
		long startTime = System.currentTimeMillis();
		boolean slowMode = "true".equalsIgnoreCase(httpRequest.getHeader("X-Slow-Mode"));
		
		//느린 모드 적용
		if(slowMode) {
			try {
				//현재 사용하고 있는 프로그램을 3초 정도 잠들게 하겠다.
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("....Slow Mode Filter doFilter 전....");
		chain.doFilter(httpRequest, response);
		
		//요청 처리 시간 출력
		long endTime = System.currentTimeMillis();
		System.out.println("요청 처리 소요 시간 : " + (endTime - startTime) + "ms");
		System.out.println("....Slow Mode Filter doFilter 후....");
	}

	

}
