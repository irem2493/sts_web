package com.example.ex11_jpa.vo;

import lombok.Data;

@Data
public class UserVo {
	private String id;
	private String pw;
	private String name;
}
