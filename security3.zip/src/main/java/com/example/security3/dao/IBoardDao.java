package com.example.security3.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.security3.entity.Board;

@Mapper
public interface IBoardDao {
	public void insertBoard(@Param("board") Board board);
	
	public List<Board> getBoardList();
	
	public int getUserBoardCnt(String username);
}
