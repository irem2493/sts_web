package com.example.rest_board2.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.rest_board2.dao.IBoardDao;
import com.example.rest_board2.domain.Board;

@RestController
@RequestMapping("/board-api")
public class BoardAPIController {
	
	@Autowired
	IBoardDao boardDao;

	//Get	-http://localhost:8080/member-api/member?username=aaa
	//username이 'aaa'인 자료를 주세요.
	@GetMapping("/board")
	public Board getBno(@RequestParam(value="bno", required=false) Integer bno) {
	    
	    if (bno == null) {
	        System.out.println("bno 파라미터가 없습니다.");
	        // 적절한 처리 (예: null 반환, 예외 던지기 등)
	        return null;  // 예시로 null 반환
	    }

	    // bno가 null이 아닌 경우에는 정상적으로 Board 객체 조회
	    Board board = boardDao.getBoard(bno);
	    return board;
	}
	
	@GetMapping("/boards")
	public List<Board> getBno() {
	    System.out.println("*************************");
	    
	    List<Board> boardList = boardDao.getBoardList();
	    return boardList;
	}
	
	//Post	-http://localhost:8080/member-api/member
	//신규 member 정보를 등록합니다.
	@PostMapping("/board")
	public String postBoard(@RequestBody Board board) {
		boardDao.regBoard(board);
		return "post";
	}
	
	//Put	-http://localhost:8080/member-api/member
	//기존 member 정보를 수정합니다.
	@PutMapping("/board")
	public String putBoard(@RequestBody Board board) {
		boardDao.updateBoard(board);
		return "put";
	}
	
	//Delete	-http://localhost:8080/member-api/member?username=aaa
	
	@DeleteMapping("/board")
	public String deleteEx(@RequestParam("bno") int bno) {
		
		boardDao.delBoard(bno);
		return "delete";
			
	}
}
