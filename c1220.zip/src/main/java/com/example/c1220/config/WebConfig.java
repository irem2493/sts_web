package com.example.c1220.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.example.c1220.filter.AuthFilter;
import com.example.c1220.filter.LogFilter;
import com.example.c1220.filter.SlowModeFilter;
import com.example.c1220.interceptor.LogInterceptor;

@Configuration
public class WebConfig implements WebMvcConfigurer{
	
	@Bean
	public FilterRegistrationBean<AuthFilter> authFilter(){
		FilterRegistrationBean<AuthFilter> filterRegistrationBean = new FilterRegistrationBean<>();
		
		filterRegistrationBean.setFilter(new AuthFilter());
		filterRegistrationBean.setOrder(2);
		filterRegistrationBean.addUrlPatterns("/secure/*");
		
		return filterRegistrationBean;
		
	}
	
	@Bean
	public FilterRegistrationBean<SlowModeFilter> slowModeFilter(){
		FilterRegistrationBean<SlowModeFilter> filterRegistrationBean = new FilterRegistrationBean<>();
		
		filterRegistrationBean.setFilter(new SlowModeFilter());
		filterRegistrationBean.setOrder(-99);
		filterRegistrationBean.addUrlPatterns("/*");
		
		return filterRegistrationBean;
		
	}
	
	
	
	@Bean
	public FilterRegistrationBean<LogFilter> logFilter(){
		FilterRegistrationBean<LogFilter> filterRegistrationBean = new FilterRegistrationBean<>();
		//필터 등록
		filterRegistrationBean.setFilter(new LogFilter());
		
		//필터 순서 지정, 숫자가 적을 수록 우선순위가 높다. 
		//스프링 시큐리티 order는 -100으로 되어있는데 그것보다 먼저 돌게 하기 위해서 -101로 설정하였다.
		filterRegistrationBean.setOrder(-101);
		
		//필터 적용 주소 지정
		
		//여러 개의 url에 필터를 적용하고 싶다면
		filterRegistrationBean.addUrlPatterns("/*");
		//filterRegistrationBean.addUrlPatterns("/s2");
		
		return filterRegistrationBean;
	}
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new LogInterceptor())
				.order(1)
				.addPathPatterns("/s1")
				.excludePathPatterns("/s2");
	}
}

