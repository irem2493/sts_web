package com.example.security.dto;


public class EncryptPW {
	
	public static String encryptPw(String pw, int key) {
		char[] pwArr = pw.toCharArray();
		String newPw = new String();
		
		for (int i = 0; i < pwArr.length; i++) {
			newPw += pwArr[i];
			for (int j = 0; j < key; j++) {
				newPw += "x";
			}
		}
		newPw += key;
		return newPw;
	}
	
	
	
}
