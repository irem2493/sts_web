package com.example.c1220.dto;

import lombok.Data;

@Data
public class LoginDto {
	private String username;
	private String password;
}
