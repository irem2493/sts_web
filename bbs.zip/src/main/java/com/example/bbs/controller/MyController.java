package com.example.bbs.controller;

import java.nio.file.spi.FileSystemProvider;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.bbs.dao.IBoardDao;
import com.example.bbs.dao.IUserDao;
import com.example.bbs.dto.BoardDTO;
import com.example.bbs.dto.PagerDTO;
import com.example.bbs.dto.UserDTO;

@Controller
public class MyController {
	@Autowired
	IBoardDao bDao;
	
	@Autowired
	IUserDao uDao;
	
	@RequestMapping("/")
	public String root(@ModelAttribute("regResult") String regResult, Model model) {
		System.out.println("list...");
		
		if(regResult.equals("success"))model.addAttribute(regResult, "success");
		else model.addAttribute(regResult, "fail");
		return "list";
	}
	
	@RequestMapping("/listPage")
	public @ResponseBody Map<String, Object> list(@RequestParam("pageNum") int pageNum) {
		System.out.println("listPage...");
		//System.out.println(pageNum+"--------------pageNum");
		int bCnt = bDao.BListCnt();
		PagerDTO pager = new PagerDTO(pageNum, bCnt, 10, 10);
		List<BoardDTO> bList = bDao.getBList(pager.getStartRow()-1, pager.getPageSize());
		for(BoardDTO b : bList)System.out.println(b);
		
		Map<String, Object> response = new HashMap<>();
        response.put("bList", bList);
        response.put("pager", pager);
        response.put("totalCount", bCnt);
        return response;
	}
	
	@GetMapping("/detail/{bno}")
	public String detail(@PathVariable("bno") int bno, Model model) {
		System.out.println(bno);
		BoardDTO board = bDao.getBoard(bno);
		if(board != null) bDao.updateRCnt(bno);
		model.addAttribute("board", board);
		return "detail";
	}
	
	@RequestMapping("/join")
	public String join() {
		System.out.println("join...");
		return "join";
	}
	@GetMapping("/checkId")
	public @ResponseBody String checkId(@RequestParam("id") String id){
		System.out.println(id.length());
		UserDTO user = null;
		String result="not use";
		if(id != null && id.length() > 0) {
			user = uDao.getUser(id);
		}
		if(user != null) result = "use";
		return result;
	}
	
	@PostMapping("/insertMember")
	public String insertMember(@ModelAttribute UserDTO userDTO, RedirectAttributes redirectAttributes) {
		System.out.println("insertMember"+userDTO);
		String regResult="fail";
		if(userDTO != null) {
			uDao.insertUser(userDTO);
			System.out.println("회원등록 성공!");
			regResult="success";
		}
		redirectAttributes.addFlashAttribute("regResult", regResult);
		return "redirect:/";
	}
}
