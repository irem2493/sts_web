package com.example.onlineTestSite.entity;

import lombok.Data;

@Data
public class Teacher {
	private String username;
	private String password;
	private String name;
	private String role;
}
