package com.example.security.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.security.dao.ILoginDao;
import com.example.security.dto.AuthObject;
import com.example.security.dto.CustomSession;
import com.example.security.dto.EncryptPW;
import com.example.security.dto.UserDto;

@Controller
public class MainController {
	@Autowired
	ILoginDao loginDao;
	
	@RequestMapping("/")
	public String root() {
		return "main";
	}

	@RequestMapping("/login")
	public String login() {
		return "login";
	}

	@RequestMapping("/join")
	public String join() {
		return "join";
	}

	@RequestMapping("/user_main")
	public String user_main() {
		return "user_main";
	}

	@RequestMapping("/admin_main")
	public String admin_main() {
		return "admin_main";
	}

	/*
	 * @RequestMapping("/loginform") public String
	 * loginform(@RequestParam("username") String
	 * username, @RequestParam("pw")String pw, Model model){
	 * System.out.println(username+", "+pw); UserDto userDto =
	 * loginDao.login(username, pw); if(userDto != null) {
	 * System.out.println(userDto); model.addAttribute("user", userDto); return
	 * "main"; } else return "join"; }
	 */

	@RequestMapping("/joinform")
	public String joinform(UserDto userDto) {
		String pw = userDto.getPw();
		Random random = new Random();
		int key = random.nextInt(5) + 1;

		String newPw = EncryptPW.encryptPw(pw, key);

		userDto.setPw(newPw);
		loginDao.join(userDto);
		return "main";
	}

	@RequestMapping("/logout")
	public String logout() {
		// session.invalidate();
		System.out.println(CustomSession.getAttribute("customSession"));
		CustomSession.removeAttribute("customSession");
		System.out.println(CustomSession.getAttribute("customSession"));
		return "main";
	}

	@RequestMapping("/loginform")
	public String loginIdform(@RequestParam("username") String username, @RequestParam("pw") String pw, Model model) {
		UserDto existUserDto = loginDao.findUsername(username);
		AuthObject authObject = new AuthObject();
		if (existUserDto != null) {
			//System.out.println(newPw + "," +epw);
			authObject.checkAuthObject(existUserDto, pw);
			
			if (authObject.isLoginYN()) {
				
				CustomSession.addAttribute("customSession", authObject);
				model.addAttribute("customSession", authObject);
				
				//System.out.println(existUserDto);
				return "main";
				
			} else return "login";
			
		} else return "join";
	}
}
