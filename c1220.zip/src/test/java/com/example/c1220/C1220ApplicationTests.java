package com.example.c1220;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C1220ApplicationTests {

	@Test
	void contextLoads() {
	}

}
