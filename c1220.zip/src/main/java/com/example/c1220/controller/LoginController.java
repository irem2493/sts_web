package com.example.c1220.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.c1220.dto.LoginDto;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class LoginController {
	
	@GetMapping("/loginForm")
	public String loginForm() {
		return "loginForm";
	}
	
	@PostMapping("/login")
	public @ResponseBody String login(LoginDto loginDto, HttpServletResponse response) {
		String id="aaa";
		String pw="1234";
		System.out.println("login....");
		
		if(id.equals(loginDto.getUsername()) && pw.equals(loginDto.getPassword())) {
			response.setHeader("Authorize","mytoken");
			return "success";
			
		}
		
		return "fail";
	}
	
	@PostMapping("/login2")
	public @ResponseBody String login2(LoginDto loginDto, HttpServletResponse response) {
		String id="aaa";
		String pw="1234";
		System.out.println("login2....");
		
		if(id.equals(loginDto.getUsername()) && pw.equals(loginDto.getPassword())) {
			response.setHeader("Authorize","mytoken");
			
			Cookie cookie = new Cookie("auth","authenticated");
			
			cookie.setHttpOnly(true);
			cookie.setMaxAge(-1);
			cookie.setPath("/");
			
			response.addCookie(cookie);
			
			return "success";
			
		}
		
		return "fail";
	}
}
