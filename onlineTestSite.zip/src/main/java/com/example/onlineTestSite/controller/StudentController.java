package com.example.onlineTestSite.controller;

import java.security.Principal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.onlineTestSite.entity.response.ExamScoreResultResponse;
import com.example.onlineTestSite.entity.response.QuestionResponse;
import com.example.onlineTestSite.service.QuestionService;

@Controller
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	QuestionService questionService;
	
	@GetMapping("/studentMain")
	public String studentMain(Model model, Principal principal) {
		List<ExamScoreResultResponse> myResultList = questionService.getMyExamScoreResult(principal.getName());
		//for(ExamScoreResultResponse e : myResultList) System.out.println(e);
		model.addAttribute("username",principal.getName());
		model.addAttribute("myResultList", myResultList);
		return "/student/studentMain";
	}
	
	@GetMapping("/studentTest")
	public String studentTest(@RequestParam("subjectId") String subjectId, Model model, Principal principal) {
		List<QuestionResponse> questionList = questionService.getQuestion5(subjectId);
		//for(QuestionResponse q : questionList)System.out.println(q);
		model.addAttribute("questionList", questionList);
		model.addAttribute("username", principal.getName());
		return "/student/studentTest";
	}
	
	@PostMapping("/calcScore")
	public String calcScore(@RequestParam Map<String, String> answers, Model model) {
		questionService.calcScore(answers);
		return "redirect:/student/studentMain";
	}
}
