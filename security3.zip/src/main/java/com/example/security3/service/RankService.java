package com.example.security3.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.security3.dao.IRankDao;

@Service
public class RankService {
	
	@Autowired
	IRankDao rankDao;
	
	public void registRank(String username) {
		rankDao.insertRank(username);
	}
	
	public void updateRank(String username) {
		rankDao.updateRank(username);
	}
}
