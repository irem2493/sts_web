package com.example.bbs.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.bbs.dao.IBoardDao;
import com.example.bbs.dao.IUserDao;
import com.example.bbs.dto.BoardDTO;
import com.example.bbs.dto.PagerDTO;
import com.example.bbs.dto.UserDTO;
import com.example.bbs.vo.UserVo;

import jakarta.servlet.http.HttpSession;

@Controller
public class MyController {
	@Autowired
	IBoardDao bDao;
	
	@Autowired
	IUserDao uDao;
	
	@Value("${spring.servlet.multipart.location}")
	private String uploadPath;
	
	@RequestMapping("/")
	public String root(@ModelAttribute("regResult") String regResult, Model model) {
		if(regResult.equals("success"))model.addAttribute(regResult, "success");
		else model.addAttribute(regResult, "fail");
		return "main";
	}
	
	@RequestMapping("/list")
	public String list() {
		System.out.println("list...");
		return "list";
	}
	
	@RequestMapping("/listPage")
	public @ResponseBody Map<String, Object> list(@RequestParam("pageNum") int pageNum) {
		System.out.println("listPage...");
		//System.out.println(pageNum+"--------------pageNum");
		int bCnt = bDao.BListCnt();
		PagerDTO pager = new PagerDTO(pageNum, bCnt, 10, 10);
		List<BoardDTO> bList = bDao.getBList(pager.getStartRow()-1, pager.getPageSize());
		for(BoardDTO b : bList)System.out.println(b);
		
		Map<String, Object> response = new HashMap<>();
        response.put("bList", bList);
        response.put("pager", pager);
        response.put("totalCount", bCnt);
        return response;
	}
	
	@GetMapping("/detail/{bno}")
	public String detail(@PathVariable("bno") int bno, Model model) {
		System.out.println(bno);
		BoardDTO board = bDao.getBoard(bno);
		if(board != null) bDao.updateRCnt(bno);
		model.addAttribute("board", board);
		return "detail";
	}
	
	@RequestMapping("/join")
	public String join() {
		System.out.println("join...");
		return "join";
	}
	@GetMapping("/checkId")
	public @ResponseBody String checkId(@RequestParam("id") String id){
		System.out.println(id.length());
		UserDTO user = null;
		String result="not use";
		if(id != null && id.length() > 0) {
			user = uDao.getUser(id);
		}
		if(user != null) result = "use";
		return result;
	}
	
	@PostMapping("/insertMember")
	public String insertMember(@ModelAttribute UserDTO userDTO, RedirectAttributes redirectAttributes) {
		System.out.println("insertMember"+userDTO);
		String regResult="fail";
		if(userDTO != null) {
			uDao.insertUser(userDTO);
			System.out.println("회원등록 성공!");
			regResult="success";
		}
		redirectAttributes.addFlashAttribute("regResult", regResult);
		return "redirect:/";
	}
	
	@RequestMapping("/login")
	public String login() {
		System.out.println("login...");
		return "login";
	}
	
	@PostMapping("/loginUser")
	public String loginUser(@RequestParam("id") String id, @RequestParam("pw") String pw, 
			HttpSession session, RedirectAttributes rttr) {
		System.out.println("loginUser...");
		UserDTO userDto = uDao.loginUser(id, pw);
		if(userDto != null) {
			session.setAttribute("user", userDto);
			return "redirect:/";
		}
		else {
			rttr.addFlashAttribute("loginYN", "fail");
			return "join";
		}
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		System.out.println("logout...");
		session.invalidate();
		return "main";
	}
	
	@RequestMapping("/myPage")
	public String myPage(HttpSession session, Model model) {
		String userId = (String)session.getAttribute("userId");
		System.out.println("myPage..." + userId);
		UserDTO userDto = uDao.getUser(userId);
		model.addAttribute("user", userDto);
		return "myPage";
	}
	
	@PostMapping("/modifyMember")
	public String modifyMember(UserVo userVo) {
		//파일 쓰기
		MultipartFile file = userVo.getFile();
		String filename = file.getOriginalFilename();
		File uploadFile = new File(uploadPath + filename);
		
		try {
			file.transferTo(uploadFile);
		}catch(IllegalStateException | IOException e) {
			e.printStackTrace();
		}
		
		UserDTO user = new UserDTO();
		user.setUno(userVo.getUno());
		user.setId(userVo.getId());
		user.setPw(userVo.getPw());
		
		if(userVo.getFile() != null) user.setFilename(filename);
		if(userVo.getPostcode() != null) user.setPostcode(userVo.getPostcode());
		if(userVo.getJibunAddress() != null) user.setJibunAddress(userVo.getJibunAddress());
		if(userVo.getDetailAddress() != null) user.setDetailAddress(userVo.getDetailAddress());
		if(userVo.getExtraAddress() != null) user.setExtraAddress(userVo.getExtraAddress());
		
		
		
		return "";
	}
}
