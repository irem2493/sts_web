package com.example.bbs.dto;

import lombok.Data;

@Data
public class PagerDTO {
	private int pageNum;	//페이지의 번호
	private int totalBoard;	//게시글의 총개수
	private int pageSize;	//한 페이지에 출력되는 게시글 개수(10개씩 보기)
	private int blockSize;	//한 블럭에 출력되는 페이지 번호 개수
	
	private int totalPage;	//전체 페이지 개수
	private int startRow;	//요청 페이지에 출력되는 게시글의 시작 행번호
	private int endRow; 	//요청 페이지에 출력되는 게시글의 종료 행번호
	private int startPage;	//블럭에 출력되는 시작 페이지 번호
	private int endPage;	//블럭에 출력되는 종료 페이지 번호
	private int prePage;	//이전 블럭에 출력되는 시작 페이지의 번호
	private int nextPage;	//다음 블럭에 출력되는 시작 페이지 번호
	
	public PagerDTO(int pageNum, int totalBoard, int pageSize, int blockSize) {
		this.pageNum = pageNum;
		this.totalBoard = totalBoard;
		this.pageSize = pageSize;
		this.blockSize = blockSize;
		
		calcPage();
	}
	
	private void calcPage() {
	    // 총 게시물 수에 페이지당 표시되는 게시물 수를 나눠 전체 페이지의 개수를 구합니다. 
	    totalPage = (int)Math.ceil((double)totalBoard / pageSize);

	    if (pageNum <= 0 || pageNum > totalPage) {
	        pageNum = 1;
	    }

	    // 시작 및 끝 행 번호
	    startRow = (pageNum - 1) * pageSize + 1;
	    endRow = pageNum * pageSize;
	    if (endRow > totalBoard) {
	        endRow = totalBoard;
	    }

	    // 한 블럭에 출력되는 페이지 번호를 계산
	    startPage = (pageNum - 1) / blockSize * blockSize + 1;
	    endPage = startPage + blockSize - 1;
	    if (endPage > totalPage) {
	        endPage = totalPage;
	    }

	    // 이전 및 다음 블럭의 시작 페이지 번호 계산
	    prePage = startPage - blockSize;
	    if (prePage < 1) {
	        prePage = 0;  // 첫 페이지보다 작은 값이 나오지 않도록 처리
	    }

	    nextPage = startPage + blockSize;
	    if (nextPage > totalPage) {
	        nextPage = totalPage;  // 마지막 페이지가 넘어가지 않도록 처리
	    }
	}
}
