package com.example.security3.dao;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface IRankDao {
	
	public void insertRank(String username);
	
	public void updateRank(String username);
}
