package com.example.c1220.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MyController {
	
	@GetMapping("/s1")
	public String s1(Model model) {
		System.out.println("Controller...s1");
		String[] messages = {"고마워","사랑해","미안해"};
		int idx = (int)(Math.random()*3);
		model.addAttribute("msg", messages[idx]);
		return "s1";
	}
	
	@GetMapping("/s2")
	public String s2(Model model) {
		System.out.println("Controller...s2");
		String[] messages = {"기운내","자랑스러워","멋져"};
		int idx = (int)(Math.random()*3);
		model.addAttribute("msg", messages[idx]);
		return "s2";
	}
}
