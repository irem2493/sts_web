package com.example.rest_board2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestBoard2Application {

	public static void main(String[] args) {
		SpringApplication.run(RestBoard2Application.class, args);
	}

}
