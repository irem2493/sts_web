package com.example.onlineTestSite.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.onlineTestSite.dao.IQuestionDao;
import com.example.onlineTestSite.entity.response.Question;

@Service
public class QuestionService {
	
	@Autowired
	IQuestionDao questionDao;
	
	public List<Question> getQuestion5() {
		List<Question> questionList = questionDao.getQuestion5();
		for(int i=0; i<questionList.size(); i++) {
			questionList.get(i).setSelectAnswerList(questionDao.getSelectList(questionList.get(i).getQuestionId()));
		}
		return questionList;
	}
}
