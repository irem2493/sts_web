package com.example.testWeb.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.testWeb.dto.BoardDto;

@SpringBootTest
class BoardDaoTest {
	
	@Autowired
	IBoardDao boardDao;
	
	@Test
	void testInsert() {		
		
		int result = 0;
		for(int count = 1; count < 25; count++) {
			
			BoardDto board = BoardDto.builder()
					.title("test" + count)
					.content("test 내용" + count)
					.writer("admin")
					.filename("ready.png")
					.build();
			
			result+=boardDao.insert(board);
		}
		assertEquals(result,24);
	}

}
