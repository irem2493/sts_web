package com.example.onlineTestSite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineTestSiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineTestSiteApplication.class, args);
	}

}
