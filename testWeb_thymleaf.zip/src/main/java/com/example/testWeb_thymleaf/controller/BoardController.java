package com.example.testWeb_thymleaf.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.testWeb_thymleaf.dto.BoardDto;
import com.example.testWeb_thymleaf.dto.PagerDto;
import com.example.testWeb_thymleaf.service.IBoardService;
import com.example.testWeb_thymleaf.vo.BoardVo;

@Controller
@RequestMapping("/board")
public class BoardController {
	@Value("${spring.servlet.multipart.location}")
	private String uploadPath;
	
	@Autowired
	IBoardService boardService;
	
	
	@RequestMapping("/registForm")
	public String regstForm() {
		System.out.println("board...registForm...");
		return "/board/registForm";
	}
	
	@RequestMapping("/regist")
	public String regist(BoardVo vo) {
		System.out.println("board...regist..."+vo);
		
		//파일 쓰기
		MultipartFile file = vo.getFile();
		String filename = file.getOriginalFilename();
		File uploadFile = new File(uploadPath + filename);
		
		try {
			file.transferTo(uploadFile);
		}catch(IllegalStateException | IOException e) {
			e.printStackTrace();
		}
		
		//파일 이름을 BoardDto에 저장하기
		//BoardDto에 @Builder를 추가하고 @@AllArgsConstructor, @NoArgsConstructor를 추가하면 이대로 사용할 수 있다.
		BoardDto board = new BoardDto();
		board.setTitle(vo.getTitle());
		board.setContent(vo.getContent());
		board.setWriter(vo.getWriter());
		board.setFilename(filename);
		
		int result = boardService.regist(board);
		return "redirect:/board/list";
	}
	
	@RequestMapping("/list")
	public String list(Model model) {
		//DB에서 tbl_board 테이블의 데이터들을 가져온다. => Service --> Dao
		List<BoardDto> boardList = boardService.getList();
		//가져온 데이터를 view(list.jsp)에 전단한다.  => Model 
		model.addAttribute("list",boardList);
		return "board/list";
	}
	
	@RequestMapping("/list2/{pageNum}")
	public String list2(@PathVariable("pageNum") int pageNum, @RequestParam(value="amount", defaultValue="5") int amount, Model model) {
		System.out.println("***Controller - list2 >> "+pageNum);
		System.out.println(amount);
		
		//페이지 수 정하기
		int totalCnt = boardService.getCount();
		System.out.println(pageNum+", "+ totalCnt+", "+amount);
		PagerDto pager = new PagerDto(pageNum,totalCnt,amount);
		System.out.println(pager.getPageNum());
		List<BoardDto> boardList = boardService.getListWithPaging(pager.getStartNum(), pager.getAmount());
		model.addAttribute("list",boardList);
		model.addAttribute("currentPageNum", pageNum);
		model.addAttribute("pager",pager);
		model.addAttribute("amount", amount);
		return "/board/list2";
	}
	
	@RequestMapping("/detail/{bno}")
	public String detail(@PathVariable("bno") int bno, Model model) {
		//파라미터(게시글을 특정할 수 있는 파라미터 : bno)
		System.out.println("detail..." + bno);
		//bno -> Dao 해당 bno의 게시글 데이터를 가져온다.
		BoardDto board = boardService.getBoard(bno);
		//가져온 데이터를 view(detail.jsp)에 전달한다.
		model.addAttribute("board", board);
		return "/board/detail";
	}
	
	@RequestMapping("/update")
	public String update(BoardVo vo) {
		System.out.println("board...update..."+vo);
		
		//파일 쓰기
		MultipartFile file = vo.getFile();
		String filename = file.getOriginalFilename();
		File uploadFile = new File(uploadPath + filename);
		
		try {
			file.transferTo(uploadFile);
		}catch(IllegalStateException | IOException e) {
			e.printStackTrace();
		}
		BoardDto board = new BoardDto();
		board.setBno(vo.getBno());
		board.setTitle(vo.getTitle());
		board.setContent(vo.getContent());
		board.setWriter(vo.getWriter());
		board.setFilename(filename);
		int result = boardService.modifyBoard(board);
		
		return "redirect:/board/list";
	}
	
	@RequestMapping("/delete/{bno}")
	public String detele(@PathVariable("bno") int bno, Model model) {
		System.out.println("board...delete..."+bno);
		int result = boardService.removeBoard(bno);
		return "redirect:/board/list";
	}
}
