package com.example.testWeb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.testWeb.dao.IBoardDao;
import com.example.testWeb.dto.BoardDto;

@Service
public class BoardService implements IBoardService{
	@Autowired
	IBoardDao boardDao;
	
	@Override
	public int regist(BoardDto board) {
		System.out.println("service..regist.."+board);
		int result = boardDao.insert(board);
		return result;
	}

	@Override
	public List<BoardDto> getList() {
		System.out.println("service...getList...");
		List<BoardDto> list = boardDao.findAll();
		return list;
	}

	@Override
	public BoardDto getBoard(int bno) {
		System.out.println("service...getBoard.." + bno);
		BoardDto board = boardDao.findByBno(bno);
		return board;
	}

	@Override
	public int modifyBoard(BoardDto board) {
		System.out.println("service...modifyBoard.." + board);
		int result = boardDao.update(board);
		return result;
	}

	@Override
	public int removeBoard(int bno) {
		System.out.println("service...removeBoard.." + bno);
		int result = boardDao.delete(bno);
		return result;
	}

	@Override
	public List<BoardDto> getListWithPaging(int startNum, int endNum) {
		System.out.println("***service - getListWithPaging >> "+startNum);
		List<BoardDto> list = boardDao.findAllPaging(startNum, endNum);
		return list;
	}

	@Override
	public int getCount() {
		int count = boardDao.findCount();
		return count;
	}

}
