package com.example.ex11_jpa.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.ex11_jpa.entity.Memo;

import jakarta.transaction.Transactional;

public interface MemoRepository extends JpaRepository<Memo, Long>{
	/*쿼리 메소드*/
	Page<Memo> findByWriter(String writer, Pageable pageable);
	Page<Memo> findByMnoBetween(Long from, Long to, Pageable pageable);
	void deleteMemoByMnoLessThan(Long mno);
	
	/*JPQL*/
	@Query("SELECT m FROM Memo m")
	List<Memo> getList();
	
	@Query("SELECT m FROM Memo m WHERE m.mno = :mno")
	Memo getMemo(@Param("mno") Long mno);
	
	@Query("SELECT COUNT(*) FROM Memo")
	int getCount();
	
	@Query("SELECT m FROM Memo m WHERE m.memoText LIKE :keyword")
	List<Memo> getListWithKeyword(@Param("keyword") String keyword);
	
	@Query("SELECT m FROM Memo m WHERE m.memoText LIKE CONCAT('%', :keyword,'%')")
	List<Memo> getListWithKeyword2(@Param("keyword") String keyword);
	
	@Transactional
	@Modifying
	@Query("UPDATE Memo m SET m.memoText = :#{#param.memoText}, m.writer = :#{#param.writer} WHERE m.mno = :#{#param.mno}")
	int updateMemo(@Param("param") Memo memo);
	
	@Transactional
	@Modifying
	@Query("INSERT INTO Memo m (m.memoText, m.writer) VALUES (:#{#param.memoText}, :#{#param.writer})")
	int insertMemo(@Param("param") Memo memo);
	
	@Transactional
	@Modifying
	@Query("DELETE FROM Memo m WHERE m.mno = ?1")
	int deleteMemo(Long mno);
	
	
	//Native Query
	@Query(value="SELECT * FROM tbl_memo", nativeQuery = true)
	List<Memo> getListNative();
}
