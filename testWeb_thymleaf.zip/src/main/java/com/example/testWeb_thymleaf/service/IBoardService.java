package com.example.testWeb_thymleaf.service;

import java.util.List;

import com.example.testWeb_thymleaf.dto.BoardDto;


public interface IBoardService {
	public int regist(BoardDto board);
	public List<BoardDto> getList();
	
	//목록조회-페이지네이션1
	public List<BoardDto> getListWithPaging(int startNum, int endNum);
	
	//전체 게시글 수
	public int getCount();
	
	public BoardDto getBoard(int bno);
	public int modifyBoard(BoardDto board);
	public int removeBoard(int bno);
}
