package com.example.ex11_jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ex11_jpa.entity.User;

public interface UserRepository extends JpaRepository<User, String>{
	User findByIdAndPw(String id, String pw);
}
