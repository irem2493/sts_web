package com.example.onlineTestSite.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.onlineTestSite.entity.Student;

@Mapper
public interface IStudentDao {
	
	public void insertStudent(@Param("student")Student student);
	
	public Student findByStudentname(String username);
}
