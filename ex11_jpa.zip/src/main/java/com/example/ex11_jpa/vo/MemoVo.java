package com.example.ex11_jpa.vo;

import lombok.Data;

@Data
public class MemoVo {
	private Long mno;
	private String writer;
	private String memoText;
}
