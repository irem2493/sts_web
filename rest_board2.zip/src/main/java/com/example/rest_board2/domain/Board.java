package com.example.rest_board2.domain;

import lombok.Data;

@Data
public class Board {
	private int bno;
	private String title;
	private String content;
	private String regdate;
	private String moddate;
	private String username;
}
