package com.example.c1220;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C1220Application {

	public static void main(String[] args) {
		SpringApplication.run(C1220Application.class, args);
	}

}
