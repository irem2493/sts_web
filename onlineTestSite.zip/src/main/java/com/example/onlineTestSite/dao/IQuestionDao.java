package com.example.onlineTestSite.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.onlineTestSite.entity.request.ExampleRequest;
import com.example.onlineTestSite.entity.response.ExamScoreResultResponse;
import com.example.onlineTestSite.entity.response.QuestionResponse;

@Mapper
public interface IQuestionDao {
	
	public List<QuestionResponse> getQuestion5(String subjectId);
	
	public List<String> getSelectList(String questionId);
	
	public void insertExamScore(@Param("Example") ExampleRequest Example);
	
	public void updateExamScoreAC(@Param("subjectId")String subjectId, @Param("username")String username);
	
	public void updateExamScoreSA(@Param("subjectId")String subjectId, @Param("username")String username);
	
	public void insertExamScoreResult(@Param("subjectId")String subjectId, @Param("username")String username);
	
	public List<ExamScoreResultResponse> selectMyExamScore(String username);
	
	public List<ExamScoreResultResponse> selectExamScore();
}
